#basic
print("Welcome to BeGenX")
print("ADVICA")
name = "Nikhil"
age = 19
price = 25.99
print(price)
print(name)
print(age)
print(type(name))
print(type(age))
print(type(price))
age = 23
old = True
a = None
print(type(old))
print(type(a))
c=20
d=5
sum = c+d
sub = c-d
mult = c*d
divide = c/d
print(sum)
print(sub)
print(mult)
print(divide)